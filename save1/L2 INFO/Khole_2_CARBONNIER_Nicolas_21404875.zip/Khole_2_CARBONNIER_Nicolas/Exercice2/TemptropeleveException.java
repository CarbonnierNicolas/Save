
/**
 * Write a description of class TemptropeleveException here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TemptropeleveException extends Exception
{

    /**
     * Constructor for objects of class TemptropeleveException
     */
    public TemptropeleveException()
    {
        System.out.println("Température trop élévée");
    }
}
