import java.util.*;
/**
 * Write a description of class ImprimeException here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ImprimeException extends Exception
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class ImprimeException
     */
    public ImprimeException()
    {
        System.out.println("Présence d'imprimée, veuillez retourner le vêtement");
    }
}
